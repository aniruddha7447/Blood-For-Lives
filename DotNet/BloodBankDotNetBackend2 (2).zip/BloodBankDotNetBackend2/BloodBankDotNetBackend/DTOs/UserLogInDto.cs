namespace BloodBankDotNetBackend.DTOs
{
    public class UserLogInDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}