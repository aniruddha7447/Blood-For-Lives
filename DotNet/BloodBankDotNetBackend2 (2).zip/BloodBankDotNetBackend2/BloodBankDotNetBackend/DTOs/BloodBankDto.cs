namespace BloodBankDotNetBackend.DTOs
{
    public class BloodBankDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public string ContactNumber { get; set; }
    }
}