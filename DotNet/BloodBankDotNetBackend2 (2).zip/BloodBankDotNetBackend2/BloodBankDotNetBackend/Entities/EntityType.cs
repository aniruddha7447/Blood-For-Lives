namespace BloodBankDotNetBackend.Entities
{
    public enum EntityType
    {
        EVENT_ADDRESS,
        USER_ADDRESS
    }
}