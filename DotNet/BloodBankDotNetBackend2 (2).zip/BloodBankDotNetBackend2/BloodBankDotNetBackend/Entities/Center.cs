namespace BloodBankDotNetBackend.Entities
{
    public enum Center
    {
        SURAT,
        AHMEDABAD,
        THANE,
        PUNE
    }
}