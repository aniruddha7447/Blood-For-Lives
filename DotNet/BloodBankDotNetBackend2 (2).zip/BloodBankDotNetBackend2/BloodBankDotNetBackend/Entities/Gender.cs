namespace BloodBankDotNetBackend.Entities
{
    public enum Gender
    {
        MALE,
        FEMALE,
        OTHER
    }
}