namespace BloodBankDotNetBackend.Entities
{
    public enum Role
    {
        ROLE_USER,
        ROLE_ADMIN
    }
}