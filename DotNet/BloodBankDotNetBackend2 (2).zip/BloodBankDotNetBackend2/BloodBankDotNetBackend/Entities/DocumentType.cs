namespace BloodBankDotNetBackend.Entities
{
    public enum DocumentType
    {
        // Add document types as needed, based on your Java enum
    }
}