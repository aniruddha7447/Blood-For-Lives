namespace BloodBankDotNetBackend.Entities
{
    public enum Status
    {
        APPROVED,
        PENDING,
        REJECTED
    }
}